


import React, {
  Component } from
  "react";
  import { Link } from "react-router-dom";
  import {ListGroup}  from 'react-bootstrap';
  import axios
  from 'axios';
  
  import Card
  from 'react-bootstrap/Card';
  
  import { CardBody,
  CardHeader,CardFooter} from
  'reactstrap';
  
  //  import UserNavComponent from "../../../usernavcomponent";

  class UserProfile
  extends Component {
  
  baseurl="http://localhost:3002/Signup"
  
  
  
  constructor(props) {
  
  super(props);
  
  this.state = {
  
  loggedinuser:{ }
  
  
  };
  
  }
  
  getProfile = () => {
  
  axios.get(this.baseurl).then((response) => {
  
  this.setState({
  email: response.data })
  
  console.log(this.state.email)
  
  for(let
  i=0;i<response.data.length;i++){
  
  if(response.data[i].email==sessionStorage.getItem('username')){
  
  this.setState({
  
  loggedinuser:response.data[i]
  
  })
  
  }
  
  }
  
  });
  
  }
  
  componentDidMount() {
  
  this.getProfile();
  
  console.log(this.state.loggedinuser)
  
  }
  
  render() { 
  
  return (
  
  <div>
  
  {/* <UserNavComponent/> */}
  <div className="row">
  <div className="container">
  

  
  <div className="col-lg-3">
  
  <Card>
  
  <CardHeader>
  
  <h3 text-align="right">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
  UserProfile</h3>

  <Card>
            <CardHeader>
               <a href="#">
                 <img className="img-fluid img-circle" src={require('../../userhome/pic1.jpg')}
                  align="center" width="200px" height="200px"/>

                 <h2>{this.state.loggedinuser.firstname}
  {this.state.loggedinuser.lastname}</h2>
  
  <h4>{this.state.loggedinuser.userType}</h4>
  
  <h4>Email id: 
  {this.state.loggedinuser.email}</h4>

               </a>
               </CardHeader>

            <CardBody>
               <font size="2" className="h9 text-muted">Connections&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <a href="#">50</a>
               </font>
               <br/>
               <font size="2" className="h9 text-muted">Following&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <a href="#">50</a>
               </font>
            </CardBody>
            <CardFooter>
                <font size="2" className="h9 text-muted" >Persons viewed your profile </font>&nbsp;
                <a href="#">50</a>
            </CardFooter>

          </Card>
           <br />
           <Card>
           <CardHeader>
              <font size="2" className="h9 text-muted">Recent</font><br/>
                <font size="2.8" className="h9">#
                  <a href="#">Capgemini</a>
                </font>
              <br/>

              <font size="2.8" className="h9">#
                <a href="#">Accenture</a>
              </font><br/>
              <font size="2.8" className="h9">#
                <a href="#">Wipro</a>
              </font><br/>
              <font size="2.8" className="h9">#
                <a href="#">Tech Mahindra</a>
              </font>
              <br/><br/>
                <a href="#">Groups</a>
              <br/>
              <font size="2.8" className="h9">#
                <a href="#">IT</a>
              </font>
              <br/>
              <font size="2.8" className="h9">#
                <a href="#">BPO</a>
              </font>
              <br/>
              <font size="2.8" className="h9">#
                <a href="#">Services</a>
              </font>
              <br/>
              <font size="2.8" className="h9">#              
                <a href="#">Electronics</a>
              </font> 
              <br/>
            </CardHeader>              
          </Card>
       
  

  
  </CardHeader>
  
  
  
  
  </Card>
  
  <br />
  
  
  </div>

  <div className="col-lg-6">
  
  <Card>
  
  <CardHeader>
  
  <br/>
  
  <h3>Details</h3>
  
  </CardHeader>
  
  <CardBody>
  
  <a href={'/addskill'}
  className="btn btn-primary ">Add Skill</a>
  
  <br/>
  
  <br/>
  
  <a href ={'/showskill'}
  className="btn btn-info">Show Skill</a>
<br/>
          <br/>
          <a href={'/addexp'}
  className="btn btn-primary ">Add Expierence</a>
  
  <br/>
  
  <br/>

<a href={'/showexp'} className="btn btn-primary ">show expiernce</a>
          <br/>
          <br/>
  
  </CardBody>

  </Card>
         
 

  
  <br />
  
  </div> 
  
  </div>
  
  <br/>
  
  </div> 
  
  <br/>
  
  <br/>
  
  <br/>
  
  </div>
  
  
  );
  
  }
  
  }
  
  
  
  export default
  UserProfile;
  

