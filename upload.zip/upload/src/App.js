import React, { Component } from 'react';
import './App.css';
import {BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import About from './components/user/about';
import UserHome from './components/profile/userhome';
import UserNetwork from './components/profile/mynetwork';
import UserJob from './components/profile/jobs';
import PostJob from './components/usernavcomponents/Jobs/Organization/postjob';
import ProfileDisplay from './components/usernavcomponents/Jobs/User/viewjobs';
import UserNotification from './components/profile/notifications';
import MyProfile from './components/profile/me';

import AddExperience from './components/usernavcomponents/profile/profiledetails/addexperience';
import AddSkill from './components/usernavcomponents/profile/profiledetails/addskill';
import Menu from './components/user/core/Menu';
import Signup from './components/user/organduser/Signup';
import UserProfile from './components/usernavcomponents/profile/profiledetails/profiledetail';
import LoginOrg from './components/user/organduser/Login2';
import Register from './components/user/organduser/register';
import Login from './components/user/organduser/Login';
import OrgHome from './components/user/organduser/orghome';
import ShowSkill from './components/usernavcomponents/profile/profiledetails/showskills';
import Exp from './components/usernavcomponents/profile/profiledetails/addexperience';
import { Showexp } from './components/usernavcomponents/profile/profiledetails/showexp';

class App extends Component {
  render() {
    return (
      <Router>
      <div className="container" align="textcenter">
     
        <Switch>   
        <Route exact path='/' component={Menu}/>
        
        <Route exact path="/Signup" component={Signup}/>
        <Route exact path="/Login" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/userprofile" component={UserProfile} />
          <Route exact path="/LoginOrg" component={LoginOrg} />
         <Route exact path='/about' component={About}/>
        <Route exact path='/orghome' component={OrgHome}/>
         <Route exact path='/home' component={UserHome}/>
         <Route exact path='/userhome' component={UserHome}/>
         <Route exact path='/mynetwork' component={UserNetwork}/>
         <Route exact path='/userjob' component={UserJob}/>
         <Route exact path='/PostJob' component={PostJob}/>
         <Route exact path='/viewjobs' component={ProfileDisplay}/>
         <Route exact path='/notifications' component={UserNotification}/>
         <Route exact path='/myprofile' component={MyProfile}/>
 
         <Route exact path='/addexperience' component={AddExperience}/>
         <Route exact path='/addskill' component={AddSkill}/>
         <Route exact path='/showskill' component={ShowSkill}/>
         <Route exact path='/addexp' component={Exp}/>
         <Route exact path='/showexp' component={Showexp}/>
        </Switch>
      </div>
      </Router>
    )
}
}

export default App;
