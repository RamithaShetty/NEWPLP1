import React from 'react';
import { Link } from "react-router-dom";
import Card from 'react-bootstrap/Card';
import {ListGroup}  from 'react-bootstrap';
// import NavComponent from '../NavbarComponent/NavComponent';
import {  CardText, CardBody, CardHeader,CardFooter} from 'reactstrap';
import axios from 'axios';
export default class Cards extends React.Component {
  constructor() {
    super()
    this.state = { post: [] }

}

baseurl = "  http://localhost:3002/userhome";
getPost = () => {
    axios.get(this.baseurl).then((response) => {
        this.setState({ post: response.data })
        console.log(this.state.post)
    });
}
addPost = (post) => {
  console.log(post)
    axios.post(this.baseurl, post).then((response) => {
        this.getPost();
        alert("Post added")
    })
}

componentDidMount() {
    this.getPost();
}
  post = React.createRef();
  handleAddPost = () => {
      let contObject = { post: this.post.current.value }
      this.addPost(contObject)
  }
  render() {
    return (
      <div>
     <div className="container">
        <div className="col-lg-6">
        <Card>
          <CardHeader>
            <form className="form-group">
            <textarea rows="6" col="20"type="text" className="form-control" placeholder="Share your thoughts....."
             ref={this.post}>
            </textarea>
            </form>
          </CardHeader>
          <CardBody>
            <button className="btn btn-outline-dark" onClick={this.handleAddPost}>Post</button>
          </CardBody>
        </Card>
        <br />
          <CardBody>
            <CardText> {this.state.post.map((i) =>
                <div>
                  <h4 key={i}>
                  <h4>{i.post}</h4>
                 
                  </h4>
                </div>
                )
                }
            </CardText>
          <CardFooter>
          <a href="#" className="card-link">
            <i className="fa fa-comment"></i>Like
            </a>&nbsp;&nbsp;
            <a href="#" className="card-link">
            <i className="fa fa-comment"></i>Comment
            </a>&nbsp;&nbsp;
            <a href="#" className="card-link">
            <i className="fa fa-comment"></i>Share
            </a>&nbsp;&nbsp;
          </CardFooter>
          </CardBody>
         </div>
        <div className="col-lg-2"></div>
        <div className="col-lg-3">
          <div className="container">
            <Card style={{border:'2px solid black', width: '25rem'  }}>
              <Card.Body>
                  <div className="text-center bg-danger">
                    <Card.Title className="text-center"><b>&nbsp; &nbsp; &nbsp; &nbsp; Trending news &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;   <span class="glyphicon glyphicon-info-sign"></span></b></Card.Title>
                  </div>
              <ListGroup variant="flush">
              <ListGroup.Item><li><Link to="/connections1" >Elections are going on</Link></li><h6>15hrs ago &nbsp; &nbsp;	◘&nbsp;367 readers</h6></ListGroup.Item>
              <ListGroup.Item><li><Link to="/connections2" >AB de Villiers Comes Up With Hilarious Nickname For Virat Kohli After Eden Gardens Masterclass</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item>
              <ListGroup.Item><li><Link to="/connections3" >Google Gives Pixel 3 Owner 10 Replacement Phones Instead of Refund: Report</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;2 readers</h6></ListGroup.Item>
              <ListGroup.Item><li><Link to="/connections4" > OnePlus 7, OnePlus 7 Pro Launch Date to Be Announced on Tuesday, CEO Pete Lau Says</Link></li><h6>2m ago &nbsp; &nbsp;	◘&nbsp;500k</h6></ListGroup.Item>
              <ListGroup.Item><li><Link to="/connections5" > Hardik Panyda, KL Rahul Fined Rs. 20 Lakh Each By BCCI Ombudsman For TV Show Comments</Link></li><h6>3days ago &nbsp; &nbsp;	◘&nbsp;200readers </h6></ListGroup.Item>
              <ListGroup.Item><li><Link to="/connections6" > 10 Takeaways From 2 Rounds Of Voting In Bihar: NDA Is Squad Goals</Link></li><h6>2days ago &nbsp; &nbsp;	◘&nbsp;367,25 readers</h6></ListGroup.Item></ListGroup>      
              </Card.Body>
            </Card>
          </div>
        </div>
        </div>
        <br/>
     </div>    
   
    )
  }
}
