import React from 'react'

import UserNavComponent from '../../../usernavcomponent';
import axios from 'axios';
class Exp extends React.Component {
  constructor(props) {
    super(props);
  
    this.onChangeprevcompany = this.onChangeprevcompany.bind(this);
    this.onChangeyears = this.onChangeyears.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      prevcompany: "",
      years: ""
     
    };
  }
  onChangeprevcompany(e) {
    this.setState({
    prevcompany: e.target.value
    });
  }

  onChangeyears(e) {
    this.setState({
      years: e.target.value
    });
  }

 
  onSubmit(e) {
    e.preventDefault();
    const exp = {
      prevcompany: this.state.prevcompany,
      years: this.state.years
    };
    
    axios.post("http://localhost:3002/addexp", exp).then(function (response) {
      console.log(response.data);
    });
    this.props.history.push('/showexp');
  }
    render(){
        return(
          <div>
       <UserNavComponent/>
          <div className="container" > 
              <div className="border border-dark" align="center">
               <div className="col-lg-5" >
                 <form onSubmit={this.onSubmit}  >
                   <div className="form-group">
                     <label className="text-info">
                       {" "}
                       <h3> Previous company </h3>
                     </label>
                     <input
                       type="text"
                       className="form-control"
                       placeholder=""
                       value={this.state.prevcompany}
                       onChange={this.onChangeprevcompany}
                       required
                     />
                   </div>
                   <div className="form-group">
                     <label className="text-info">
                       <h3>Years </h3>
                     </label>
                     <input
                       type="text"
                       className="form-control"
                       placeholder=""
                       value={this.state.years}
                       onChange={this.onChangeyears}
                       required
                     />
                   </div>
                   <br />
                   <div className="form-group">
                     <input
                       type="submit"
                       value="Add "
                       className="btn btn-info"
                     />
                   </div>
                 </form>
               </div>
               </div>
             </div>
             <hr/>
          </div>
        )
    }
}
export default Exp;