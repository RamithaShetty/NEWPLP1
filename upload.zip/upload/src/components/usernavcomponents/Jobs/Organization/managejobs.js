import React, { Component } from 'react'
import UserNavComponent from '../../../usernavcomponent';

class ManageJobs extends Component {
    render() {
        return (
            <div>
            <hr/>
            <img className="img" height="200px" width="30%"  src={require('../User/google.jpg')} />
            <div className="container">
                  <h4>
                    <b>Google</b>
                  </h4>
                 
                  <div className="col-md-20">
  <a href="/viewjobs" type="submit" className="btn btn-lg btn-primary" value="post a job" >Job Details</a>
                </div>
                </div>
        
            <footer>
                    <p><i>By using this site, you agree to LinkedIn terms of use. Commercial use of this site without express authorization is prohibited.

LinkedIn Corporation © 2019</i></p>
            </footer>
            </div>

        )
    }
}

export default ManageJobs;