import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';
// import '../profile/userhome.css';
import Cards from '../usernavcomponents/userhome/UserHome';
export class UserHome extends Component {
    render() {
        const signup = this.props.userData;
        return (
            <div className="backC">
                <UserNavComponent />
                <h1>Linkedin</h1>
                <Cards/> 
            </div>
        )
    }
}

export default UserHome
