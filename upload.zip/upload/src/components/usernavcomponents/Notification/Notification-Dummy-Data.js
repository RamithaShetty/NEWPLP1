const notiDummyData = [
    {
      username: 'Amazon',
      imageUrl: 'https://media3.picsearch.com/is?bW5ytyXNFcVjxP2joxUMBI_SZDlgY0JpyzkGnxqMuMc&height=256',
      text: 'Amazon have 5 job updates',
    },
    {
      username: 'Microsoft',
      imageUrl: 'https://media3.picsearch.com/is?SK0F2y5bkxoCsNY_ysESUxS8Tkzq8w4pHeXjvZqNiX0&height=246',
      text: 'Microsoft have 2 updates'
    }
  ];
  
  export default notiDummyData;